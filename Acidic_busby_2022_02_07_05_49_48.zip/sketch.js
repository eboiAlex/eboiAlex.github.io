//not used variable since i am not sure how
let words = "some words";
function setup() {
  createCanvas(800, 800);
}

function draw() {
  background(220);
  text(frameCount, 200, 10);
  //a square which is made of ellipse but will change to words
  for(var i = 0; i < 300; i+= 50){
    for(var j = 0; j < 300; j += 50){
      ellipse(i+ 100, j + 100, 20, 20);
      }
  }
  //a square but will have to learn how to make a circle out of words
  for(var i = 0; i < 300; i+= 50){
    for(var j = 0; j < 300; j += 50){
      ellipse(i+ 500, j + 100, 20, 20);
      }
  }
  //same here instead of ellipses i will need words
  for(var i = 0; i < 700; i+= 50){
    for(var j = 0; j < 300; j += 50){
      ellipse(i+ 100, j + 500, 20, 20);
      }
  }
}